REDMINE BACKLOGS
----------------
A Redmine plugin for agile teams. For more information,
please visit http://www.redminebacklogs.net

Travis: [![Build Status](https://secure.travis-ci.org/backlogs/redmine_backlogs.png?branch=master)](http://travis-ci.org/backlogs/redmine_backlogs)

[Code climate](https://codeclimate.com/github/backlogs/redmine_backlogs) [![Code Climate](https://codeclimate.com/badge.png)](https://codeclimate.com/github/backlogs/redmine_backlogs)

LICENSE
-------
This plugin is released under the GPL v2 license. See
LICENSE for more information.

Due to time restraints I can only support the latest release, PLEASE take this into consideration before posting issues. Upgrade first.
